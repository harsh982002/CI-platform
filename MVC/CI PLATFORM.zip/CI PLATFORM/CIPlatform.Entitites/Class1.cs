﻿namespace CIPlatform.Entitites
{
    public class Class1
    {

    }
}
﻿namespace CIPlatform.Repository
{
    public class Class1
    {

    }
}